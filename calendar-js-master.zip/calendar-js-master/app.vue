<template>
  <div>
    <!-- <NuxtWelcome /> -->
    <calendar-component></calendar-component>
  </div>
</template>

<style lang="scss">
@import 'node_modules/bootstrap/scss/bootstrap-reboot.scss';
body {
  padding: 1rem;
}</style>